<?php
/* 
13 - Write a PHP program that prints the multiplication table of 8 using for loop
*/


$table = 12 ;


for($i = 1 ;$i <= $table;$i++ ){
    echo "$i * 8 " . "=" . ($i * 8) . "<br>";
}