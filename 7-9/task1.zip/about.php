<?php
  $page = 'about';
  $pageTitle = 'About Us - Simple Template';
  include 'header.php';
?>

<!-- Main Content for About Page -->
<div class="container mt-5">
  <h1>About Us</h1>
  <p>This is the about page of our simple Bootstrap template.</p>
</div>

<?php include 'footer.php'; ?>