<?php
  $page = 'home';
  $pageTitle = 'Home - Simple Template';
  include 'header.php';
?>

<!-- Main Content for Home Page -->
<div class="container mt-5">
  <h1>Welcome to the Home Page</h1>
  <p>This is the home page of our simple Bootstrap template.</p>
</div>

<?php include 'footer.php'; ?>